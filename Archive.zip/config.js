exports.PORT = 3000;
exports.COUCHBASE_ADDRESS = "127.0.0.1";